import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:8000";

export const api = axios.create({ baseURL: BASE_URL });

// Attach JWT token from localStorage on every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("nrm_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Auto-logout on 401
api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem("nrm_token");
      localStorage.removeItem("nrm_user");
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

// ── Auth ─────────────────────────────────────────────────────────────────
export const authApi = {
  login: (email: string, password: string) =>
    api.post("/auth/login", new URLSearchParams({ username: email, password }), {
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    }),
  register: (data: Record<string, unknown>) => api.post("/auth/register", data),
  me: () => api.get("/auth/me"),
  listUsers: () => api.get("/auth/users"),
  toggleUser: (id: string) => api.put(`/auth/users/${id}/toggle`),
};

// ── Entities ──────────────────────────────────────────────────────────────
export const entityApi = {
  list: () => api.get("/entities"),
  get: (id: string) => api.get(`/entities/${id}`),
  create: (data: Record<string, unknown>) => api.post("/entities", data),
  update: (id: string, data: Record<string, unknown>) => api.put(`/entities/${id}`, data),
  delete: (id: string) => api.delete(`/entities/${id}`),
  addCSF: (id: string, data: Record<string, unknown>) => api.post(`/entities/${id}/csfs`, data),
  submit: (id: string) => api.post(`/entities/${id}/submit`),
  review: (id: string, data: Record<string, unknown>) => api.post(`/entities/${id}/review`, data),
};

// ── Risks ────────────────────────────────────────────────────────────────
export const riskApi = {
  list: (entityId?: string) => api.get("/risks", { params: entityId ? { entity: entityId } : {} }),
  get: (id: string) => api.get(`/risks/${id}`),
  create: (data: Record<string, unknown>) => api.post("/risks", data),
  update: (id: string, data: Record<string, unknown>) => api.put(`/risks/${id}`, data),
  delete: (id: string) => api.delete(`/risks/${id}`),
};

// ── Treatment Plans ───────────────────────────────────────────────────────
export const treatmentApi = {
  list: (riskId?: string) => api.get("/treatment-plans", { params: riskId ? { risk: riskId } : {} }),
  create: (data: Record<string, unknown>) => api.post("/treatment-plans", data),
  update: (id: string, data: Record<string, unknown>) => api.put(`/treatment-plans/${id}`, data),
  delete: (id: string) => api.delete(`/treatment-plans/${id}`),
};

// ── KRIs ─────────────────────────────────────────────────────────────────
export const kriApi = {
  list: (riskId?: string) => api.get("/kris", { params: riskId ? { risk: riskId } : {} }),
  create: (data: Record<string, unknown>) => api.post("/kris", data),
  addEntry: (kriId: string, data: Record<string, unknown>) => api.post(`/kris/${kriId}/entries`, data),
};

// ── KPIs ─────────────────────────────────────────────────────────────────
export const kpiApi = {
  list: (entityId?: string) => api.get("/kpis", { params: entityId ? { entity: entityId } : {} }),
  create: (data: Record<string, unknown>) => api.post("/kpis", data),
  addEntry: (kpiId: string, data: Record<string, unknown>) => api.post(`/kpis/${kpiId}/entries`, data),
};

// ── Compliance ────────────────────────────────────────────────────────────
export const complianceApi = {
  list: (riskId?: string) => api.get("/compliance", { params: riskId ? { risk: riskId } : {} }),
  create: (data: Record<string, unknown>) => api.post("/compliance", data),
  addEntry: (controlId: string, data: Record<string, unknown>) =>
    api.post(`/compliance/${controlId}/entries`, data),
};

// ── Incidents ─────────────────────────────────────────────────────────────
export const incidentApi = {
  list: (entityId?: string) =>
    api.get("/incidents", { params: entityId ? { entity: entityId } : {} }),
  create: (data: Record<string, unknown>) => api.post("/incidents", data),
  update: (id: string, data: Record<string, unknown>) => api.put(`/incidents/${id}`, data),
};

// ── Aggregation ───────────────────────────────────────────────────────────
export const aggregationApi = {
  get: (entityId: string, quarter: string) => api.get(`/aggregation/${entityId}/${quarter}`),
};
