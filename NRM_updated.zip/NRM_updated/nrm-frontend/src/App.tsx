import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth, UserRole } from "./contexts/AuthContext";
import Layout from "./components/layout/Layout";
import LoginPage from "./pages/LoginPage";
import RiskChampionDashboard from "./pages/dashboard/RiskChampionDashboard";
import RiskOwnerDashboard from "./pages/dashboard/RiskOwnerDashboard";
import CoordinatorDashboard from "./pages/dashboard/CoordinatorDashboard";
import RMCDashboard from "./pages/dashboard/RMCDashboard";
import SeniorManagementDashboard from "./pages/dashboard/SeniorManagementDashboard";
import MinecofinDashboard from "./pages/dashboard/MinecofinDashboard";

const DASHBOARD_MAP: Record<UserRole, React.ReactElement> = {
  risk_champion: <RiskChampionDashboard />,
  risk_owner: <RiskOwnerDashboard />,
  coordinator: <CoordinatorDashboard />,
  rmc: <RMCDashboard />,
  senior_management: <SeniorManagementDashboard />,
  minecofin: <MinecofinDashboard />,
};

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <>{children}</> : <Navigate to="/login" replace />;
}

function DashboardRoute() {
  const { user } = useAuth();
  if (!user) return null;
  return DASHBOARD_MAP[user.role] ?? <div className="text-slate-500">Unknown role</div>;
}

// Placeholder for pages not yet built
function ComingSoon({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-20 text-slate-400">
      <div className="text-5xl mb-4">🚧</div>
      <h2 className="text-xl font-semibold text-slate-600">{title}</h2>
      <p className="text-sm mt-2">This page is under construction.</p>
    </div>
  );
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route
        path="/*"
        element={
          <ProtectedRoute>
            <Layout>
              <Routes>
                <Route path="/dashboard" element={<DashboardRoute />} />
                <Route path="/risks" element={<ComingSoon title="Risk Register" />} />
                <Route path="/treatment-plans" element={<ComingSoon title="Treatment Plans" />} />
                <Route path="/kris" element={<ComingSoon title="Key Risk Indicators" />} />
                <Route path="/kpis" element={<ComingSoon title="Key Performance Indicators" />} />
                <Route path="/compliance" element={<ComingSoon title="Compliance Management" />} />
                <Route path="/incidents" element={<ComingSoon title="Incident Management" />} />
                <Route path="/aggregation" element={<ComingSoon title="Risk Aggregation" />} />
                <Route path="/entities" element={<ComingSoon title="Entities" />} />
                <Route path="/entities/:id" element={<ComingSoon title="Entity Detail" />} />
                <Route path="/users" element={<ComingSoon title="User Management" />} />
                <Route path="/reports" element={<ComingSoon title="Reports" />} />
                <Route path="/risk-in-motion" element={<ComingSoon title="Risk in Motion" />} />
                <Route path="/consolidation" element={<ComingSoon title="Consolidation" />} />
                <Route path="/review" element={<ComingSoon title="Review & Approve" />} />
                <Route path="/top-risks" element={<ComingSoon title="Top Risks" />} />
                <Route path="/approval" element={<ComingSoon title="Approval" />} />
                <Route path="/analytics" element={<ComingSoon title="Risk Analytics" />} />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </Routes>
            </Layout>
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}
