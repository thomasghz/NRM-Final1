import { ReactNode, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth, ROLE_LABELS } from "../../contexts/AuthContext";
import {
  LayoutDashboard, Shield, FileText, AlertTriangle, BarChart2,
  CheckSquare, Activity, Users, Building2, ChevronDown,
  LogOut, Menu, X, TrendingUp
} from "lucide-react";

const NAV_ITEMS: Record<string, Array<{ label: string; path: string; icon: ReactNode }>> = {
  risk_champion: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "Risk Register", path: "/risks", icon: <Shield className="w-4 h-4" /> },
    { label: "Treatment Plans", path: "/treatment-plans", icon: <FileText className="w-4 h-4" /> },
    { label: "KRIs", path: "/kris", icon: <TrendingUp className="w-4 h-4" /> },
    { label: "KPIs", path: "/kpis", icon: <BarChart2 className="w-4 h-4" /> },
    { label: "Compliance", path: "/compliance", icon: <CheckSquare className="w-4 h-4" /> },
    { label: "Incidents", path: "/incidents", icon: <AlertTriangle className="w-4 h-4" /> },
    { label: "Risk Aggregation", path: "/aggregation", icon: <Activity className="w-4 h-4" /> },
  ],
  risk_owner: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "Risk Register", path: "/risks", icon: <Shield className="w-4 h-4" /> },
    { label: "Treatment Plans", path: "/treatment-plans", icon: <FileText className="w-4 h-4" /> },
    { label: "KRIs", path: "/kris", icon: <TrendingUp className="w-4 h-4" /> },
    { label: "KPIs", path: "/kpis", icon: <BarChart2 className="w-4 h-4" /> },
    { label: "Compliance", path: "/compliance", icon: <CheckSquare className="w-4 h-4" /> },
    { label: "Incidents", path: "/incidents", icon: <AlertTriangle className="w-4 h-4" /> },
    { label: "Risk Aggregation", path: "/aggregation", icon: <Activity className="w-4 h-4" /> },
  ],
  coordinator: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "All Entities", path: "/entities", icon: <Building2 className="w-4 h-4" /> },
    { label: "Risk in Motion", path: "/risk-in-motion", icon: <TrendingUp className="w-4 h-4" /> },
    { label: "Consolidation", path: "/consolidation", icon: <Activity className="w-4 h-4" /> },
    { label: "Reports", path: "/reports", icon: <FileText className="w-4 h-4" /> },
  ],
  rmc: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "All Entities", path: "/entities", icon: <Building2 className="w-4 h-4" /> },
    { label: "Risk in Motion", path: "/risk-in-motion", icon: <TrendingUp className="w-4 h-4" /> },
    { label: "Review & Approve", path: "/review", icon: <CheckSquare className="w-4 h-4" /> },
    { label: "Reports", path: "/reports", icon: <FileText className="w-4 h-4" /> },
  ],
  senior_management: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "Top Risks", path: "/top-risks", icon: <AlertTriangle className="w-4 h-4" /> },
    { label: "Risk Reports", path: "/reports", icon: <FileText className="w-4 h-4" /> },
    { label: "Approval", path: "/approval", icon: <CheckSquare className="w-4 h-4" /> },
  ],
  minecofin: [
    { label: "Dashboard", path: "/dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "All Entities", path: "/entities", icon: <Building2 className="w-4 h-4" /> },
    { label: "Consolidated Reports", path: "/reports", icon: <FileText className="w-4 h-4" /> },
    { label: "User Management", path: "/users", icon: <Users className="w-4 h-4" /> },
    { label: "Risk Analytics", path: "/analytics", icon: <BarChart2 className="w-4 h-4" /> },
  ],
};

const ROLE_COLORS: Record<string, string> = {
  risk_champion: "bg-emerald-600",
  risk_owner: "bg-blue-600",
  coordinator: "bg-violet-600",
  rmc: "bg-orange-600",
  senior_management: "bg-red-700",
  minecofin: "bg-slate-700",
};

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navItems = NAV_ITEMS[user?.role ?? "risk_champion"] ?? [];
  const roleColor = ROLE_COLORS[user?.role ?? "risk_champion"];

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const Sidebar = () => (
    <aside className="flex flex-col h-full bg-slate-900 w-64">
      {/* Brand */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-slate-700">
        <div className={`flex-shrink-0 w-9 h-9 rounded-lg ${roleColor} flex items-center justify-center`}>
          <Shield className="w-5 h-5 text-white" />
        </div>
        <div>
          <p className="text-white font-bold text-sm leading-tight">NRM System</p>
          <p className="text-slate-400 text-xs">Risk Management</p>
        </div>
      </div>

      {/* Role badge */}
      <div className="px-5 py-3 border-b border-slate-700">
        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold text-white ${roleColor}`}>
          {ROLE_LABELS[user?.role ?? "risk_champion"]}
        </span>
        <p className="text-slate-300 text-sm font-medium mt-1 truncate">{user?.full_name}</p>
        <p className="text-slate-500 text-xs truncate">{user?.email}</p>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                active
                  ? "bg-blue-600 text-white"
                  : "text-slate-400 hover:text-white hover:bg-slate-800"
              }`}
            >
              {item.icon}
              {item.label}
            </Link>
          );
        })}
      </nav>

      {/* Logout */}
      <div className="px-3 py-4 border-t border-slate-700">
        <button
          onClick={handleLogout}
          className="flex items-center gap-3 px-3 py-2.5 w-full rounded-lg text-sm font-medium text-slate-400 hover:text-white hover:bg-red-600/20 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign out
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex h-screen bg-slate-100 overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden lg:flex flex-col w-64 flex-shrink-0">
        <Sidebar />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="flex flex-col w-64">
            <Sidebar />
          </div>
          <div
            className="flex-1 bg-black/50"
            onClick={() => setSidebarOpen(false)}
          />
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-slate-200 px-4 py-3 flex items-center justify-between">
          <button
            className="lg:hidden text-slate-600"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="hidden lg:block" />
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-full ${roleColor} flex items-center justify-center text-white text-sm font-semibold`}>
              {user?.full_name?.charAt(0) ?? "?"}
            </div>
            <span className="text-sm text-slate-700 font-medium hidden sm:block">
              {user?.full_name}
            </span>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
