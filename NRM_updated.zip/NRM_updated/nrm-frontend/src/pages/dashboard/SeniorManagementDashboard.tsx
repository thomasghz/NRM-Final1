import { useEffect, useState } from "react";
import { entityApi, riskApi } from "../../api";
import { BarChart2, AlertTriangle, CheckCircle, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from "recharts";

const ZONE_COLORS_CHART: Record<string, string> = {
  Low: "#22c55e",
  Medium: "#eab308",
  High: "#f97316",
  Critical: "#ef4444",
};

export default function SeniorManagementDashboard() {
  const [entities, setEntities] = useState<any[]>([]);
  const [allRisks, setAllRisks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    entityApi.list().then(async (res) => {
      setEntities(res.data);
      const approved = res.data.filter((e: any) => e.submission_status === "approved");
      const riskArrays = await Promise.all(approved.map((e: any) => riskApi.list(e.id)));
      setAllRisks(riskArrays.flatMap((r) => r.data));
    }).finally(() => setLoading(false));
  }, []);

  const zoneCounts = ["Low", "Medium", "High", "Critical"].map((z) => ({
    zone: z,
    count: allRisks.filter((r) => r.rrl_zone === z).length,
    fill: ZONE_COLORS_CHART[z],
  }));

  const topRisks = [...allRisks].sort((a, b) => (b.rrl ?? 0) - (a.rrl ?? 0)).slice(0, 10);
  const approved = entities.filter((e) => e.submission_status === "approved").length;

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Senior Management Dashboard</h1>
        <p className="text-slate-500 mt-0.5">Enterprise-wide risk overview — approved reports only</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Approved Entities", value: approved, color: "text-green-600" },
          { label: "Total Risks", value: allRisks.length, color: "text-blue-600" },
          { label: "Critical Risks", value: allRisks.filter(r => r.rrl_zone === "Critical").length, color: "text-red-600" },
          { label: "High Risks", value: allRisks.filter(r => r.rrl_zone === "High").length, color: "text-orange-600" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <h2 className="font-semibold text-slate-800 mb-4">Risks by Zone</h2>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={zoneCounts} barSize={40}>
              <XAxis dataKey="zone" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                {zoneCounts.map((entry) => (
                  <Cell key={entry.zone} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Pie chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <h2 className="font-semibold text-slate-800 mb-4">Risk Distribution</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={zoneCounts.filter(d => d.count > 0)} dataKey="count" nameKey="zone"
                cx="50%" cy="50%" outerRadius={80} label>
                {zoneCounts.map((entry) => (
                  <Cell key={entry.zone} fill={entry.fill} />
                ))}
              </Pie>
              <Legend />
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Top risks */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-slate-800">Top 10 Enterprise Risks</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">#</th>
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Risk Event</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">RRL</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Zone</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {topRisks.map((r, i) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-3 py-3 text-center font-bold text-slate-400">{i + 1}</td>
                  <td className="px-5 py-3 text-slate-700">{r.risk_event}</td>
                  <td className="px-3 py-3 text-center font-bold text-slate-800">{r.rrl ?? "—"}</td>
                  <td className="px-3 py-3 text-center">
                    {r.rrl_zone && (
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold`}
                        style={{ background: ZONE_COLORS_CHART[r.rrl_zone] + "22", color: ZONE_COLORS_CHART[r.rrl_zone] }}>
                        {r.rrl_zone}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
              {topRisks.length === 0 && (
                <tr><td colSpan={4} className="px-5 py-8 text-center text-slate-400">No approved risks to display.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
