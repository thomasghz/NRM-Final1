import { useEffect, useState } from "react";
import { useAuth } from "../../contexts/AuthContext";
import { riskApi, entityApi } from "../../api";
import { Shield, AlertTriangle, CheckCircle, XCircle, MessageSquare, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function RiskOwnerDashboard() {
  const { user } = useAuth();
  const [risks, setRisks] = useState<any[]>([]);
  const [entity, setEntity] = useState<any>(null);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [comments, setComments] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.entity_id) { setLoading(false); return; }
    Promise.all([riskApi.list(user.entity_id), entityApi.get(user.entity_id)])
      .then(([r, e]) => { setRisks(r.data); setEntity(e.data); })
      .finally(() => setLoading(false));
  }, [user?.entity_id]);

  const handleReview = async (action: "approve" | "return") => {
    await entityApi.review(user!.entity_id!, { action, comments });
    const { data } = await entityApi.get(user!.entity_id!);
    setEntity(data);
    setReviewOpen(false);
    setComments("");
  };

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;

  const submitted = entity?.submission_status === "submitted";
  const criticalRisks = risks.filter((r) => r.rrl_zone === "Critical" || r.rrl_zone === "High");

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Risk Owner Dashboard</h1>
          <p className="text-slate-500 mt-0.5">{entity?.name}</p>
        </div>
        {submitted && (
          <button onClick={() => setReviewOpen(true)}
            className="flex items-center gap-2 bg-orange-500 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-orange-600">
            <MessageSquare className="w-4 h-4" /> Review Submission
          </button>
        )}
      </div>

      {/* Review modal */}
      {reviewOpen && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4">Review Risk Register</h3>
            <p className="text-sm text-slate-500 mb-3">Entity: <strong>{entity?.name}</strong></p>
            <textarea
              value={comments}
              onChange={(e) => setComments(e.target.value)}
              placeholder="Add comments for the Risk Champion..."
              className="w-full border border-slate-200 rounded-lg p-3 text-sm h-28 resize-none focus:outline-none focus:ring-2 focus:ring-blue-400"
            />
            <div className="flex gap-3 mt-4">
              <button onClick={() => handleReview("approve")}
                className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-2 rounded-lg text-sm font-semibold hover:bg-green-700">
                <CheckCircle className="w-4 h-4" /> Forward to Coordinator
              </button>
              <button onClick={() => handleReview("return")}
                className="flex-1 flex items-center justify-center gap-2 bg-red-600 text-white py-2 rounded-lg text-sm font-semibold hover:bg-red-700">
                <XCircle className="w-4 h-4" /> Return for Revision
              </button>
            </div>
            <button onClick={() => setReviewOpen(false)} className="mt-3 w-full text-slate-500 text-sm hover:text-slate-700">Cancel</button>
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Risks", value: risks.length, color: "text-blue-600 bg-blue-50" },
          { label: "Critical/High", value: criticalRisks.length, color: "text-red-600 bg-red-50" },
          { label: "To Treat", value: risks.filter(r => r.evaluation === "Treat").length, color: "text-orange-600 bg-orange-50" },
          { label: "Accepted", value: risks.filter(r => r.evaluation === "Accept").length, color: "text-green-600 bg-green-50" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <p className={`text-2xl font-bold ${s.color.split(" ")[0]}`}>{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Submission status */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h2 className="font-semibold text-slate-800 mb-3">Submission Status</h2>
        <div className="flex items-center gap-3">
          <span className={`px-3 py-1.5 rounded-lg text-sm font-semibold capitalize ${
            entity?.submission_status === "submitted" ? "bg-blue-100 text-blue-700" :
            entity?.submission_status === "approved" ? "bg-green-100 text-green-700" :
            entity?.submission_status === "returned" ? "bg-red-100 text-red-700" :
            "bg-slate-100 text-slate-600"
          }`}>
            {entity?.submission_status?.replace("_", " ") ?? "Draft"}
          </span>
          {submitted && <p className="text-sm text-slate-500">Awaiting your review before forwarding to Coordinator.</p>}
        </div>
      </div>

      {/* High-risk table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-slate-800">Critical & High Risks</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Risk Event</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">RRL</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Zone</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Evaluation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {criticalRisks.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50">
                  <td className="px-5 py-3 text-slate-700">{r.risk_event}</td>
                  <td className="px-3 py-3 text-center font-bold">{r.rrl}</td>
                  <td className="px-3 py-3 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${r.rrl_zone === "Critical" ? "bg-red-100 text-red-700" : "bg-orange-100 text-orange-700"}`}>
                      {r.rrl_zone}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-orange-100 text-orange-700">{r.evaluation}</span>
                  </td>
                </tr>
              ))}
              {criticalRisks.length === 0 && (
                <tr><td colSpan={4} className="px-5 py-8 text-center text-slate-400">No critical or high risks found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
