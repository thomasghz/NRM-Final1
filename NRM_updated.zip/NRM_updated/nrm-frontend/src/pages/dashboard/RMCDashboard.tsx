import { useEffect, useState } from "react";
import { entityApi, riskApi } from "../../api";
import { CheckCircle, XCircle, Send, Users, AlertTriangle, BarChart2 } from "lucide-react";

export default function RMCDashboard() {
  const [entities, setEntities] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [risks, setRisks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    entityApi.list().then((r) => setEntities(r.data)).finally(() => setLoading(false));
  }, []);

  const handleSelectEntity = async (entity: any) => {
    setSelected(entity);
    const { data } = await riskApi.list(entity.id);
    setRisks(data);
  };

  const underReview = entities.filter((e) => e.submission_status === "under_review");
  const approved = entities.filter((e) => e.submission_status === "approved");

  const handleApprove = async (entityId: string) => {
    await entityApi.update(entityId, { submission_status: "approved" });
    const { data } = await entityApi.list();
    setEntities(data);
    setSelected(null);
  };

  const handleReturn = async (entityId: string, comments: string) => {
    await entityApi.update(entityId, { submission_status: "returned", risk_owner_comments: comments });
    const { data } = await entityApi.list();
    setEntities(data);
    setSelected(null);
  };

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Risk Management Committee</h1>
        <p className="text-slate-500 mt-0.5">Review consolidated risk reports and approve for Senior Management</p>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
          <p className="text-3xl font-bold text-amber-600">{underReview.length}</p>
          <p className="text-sm text-slate-500 mt-1">Awaiting RMC Review</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
          <p className="text-3xl font-bold text-green-600">{approved.length}</p>
          <p className="text-sm text-slate-500 mt-1">Approved</p>
        </div>
        <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
          <p className="text-3xl font-bold text-blue-600">{entities.length}</p>
          <p className="text-sm text-slate-500 mt-1">Total Entities</p>
        </div>
      </div>

      {/* Pending review */}
      {underReview.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
          <h2 className="font-semibold text-slate-800 mb-4">Pending Your Review</h2>
          <div className="space-y-2">
            {underReview.map((e) => (
              <div key={e.id} className="flex items-center justify-between p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <div>
                  <p className="font-medium text-slate-800">{e.name}</p>
                  <p className="text-xs text-slate-500">{e.assessed_unit} · {e.fiscal_year}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleSelectEntity(e)}
                    className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                    Review
                  </button>
                  <button onClick={() => handleApprove(e.id)}
                    className="px-3 py-1.5 text-xs font-semibold bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Approve
                  </button>
                  <button onClick={() => { const c = prompt("Return reason:"); if (c) handleReturn(e.id, c); }}
                    className="px-3 py-1.5 text-xs font-semibold bg-red-600 text-white rounded-lg hover:bg-red-700 flex items-center gap-1">
                    <XCircle className="w-3 h-3" /> Return
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Selected entity detail */}
      {selected && risks.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between">
            <h2 className="font-semibold text-slate-800">Reviewing: {selected.name}</h2>
            <button onClick={() => setSelected(null)} className="text-slate-400 hover:text-slate-600 text-sm">Close</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-slate-50">
                  <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Risk Event</th>
                  <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">IRL</th>
                  <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">RRL</th>
                  <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Zone</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {risks.map((r) => (
                  <tr key={r.id}>
                    <td className="px-5 py-3 text-slate-700">{r.risk_event}</td>
                    <td className="px-3 py-3 text-center">{r.irl ?? "—"}</td>
                    <td className="px-3 py-3 text-center font-bold">{r.rrl ?? "—"}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${r.rrl_zone === "Critical" ? "bg-red-100 text-red-700" : r.rrl_zone === "High" ? "bg-orange-100 text-orange-700" : "bg-yellow-100 text-yellow-700"}`}>
                        {r.rrl_zone ?? "—"}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
