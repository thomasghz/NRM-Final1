import { useEffect, useState } from "react";
import { entityApi, riskApi, authApi } from "../../api";
import { Building2, Users, Shield, AlertTriangle, BarChart2, Globe, TrendingUp } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, LineChart, Line, Legend } from "recharts";

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#06b6d4"];
const ZONE_COLORS: Record<string, string> = { Low: "#22c55e", Medium: "#eab308", High: "#f97316", Critical: "#ef4444" };

export default function MinecofinDashboard() {
  const [entities, setEntities] = useState<any[]>([]);
  const [allRisks, setAllRisks] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"overview" | "entities" | "users">("overview");

  useEffect(() => {
    Promise.all([entityApi.list(), authApi.listUsers()]).then(async ([entRes, usrRes]) => {
      setEntities(entRes.data);
      setUsers(usrRes.data);
      const riskArrays = await Promise.all(entRes.data.map((e: any) => riskApi.list(e.id)));
      setAllRisks(riskArrays.flatMap((r) => r.data));
    }).finally(() => setLoading(false));
  }, []);

  const entityRiskCounts = entities.map((e, i) => ({
    name: e.name.length > 12 ? e.name.slice(0, 12) + "…" : e.name,
    risks: allRisks.filter((r) => r.entity_id === e.id).length,
    fill: COLORS[i % COLORS.length],
  }));

  const zoneSummary = ["Low", "Medium", "High", "Critical"].map((z) => ({
    zone: z,
    count: allRisks.filter((r) => r.rrl_zone === z).length,
  }));

  const ROLE_LABELS: Record<string, string> = {
    risk_champion: "Risk Champion", risk_owner: "Risk Owner",
    coordinator: "Coordinator", rmc: "RMC",
    senior_management: "Senior Mgmt", minecofin: "MINECOFIN",
  };

  const handleToggleUser = async (userId: string) => {
    await authApi.toggleUser(userId);
    const { data } = await authApi.listUsers();
    setUsers(data);
  };

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">MINECOFIN Dashboard</h1>
        <p className="text-slate-500 mt-0.5">National consolidated risk management overview</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Public Entities", value: entities.length, icon: <Building2 className="w-5 h-5" />, color: "text-blue-600 bg-blue-50" },
          { label: "Total Risks", value: allRisks.length, icon: <Shield className="w-5 h-5" />, color: "text-violet-600 bg-violet-50" },
          { label: "Critical Risks", value: allRisks.filter(r => r.rrl_zone === "Critical").length, icon: <AlertTriangle className="w-5 h-5" />, color: "text-red-600 bg-red-50" },
          { label: "System Users", value: users.length, icon: <Users className="w-5 h-5" />, color: "text-emerald-600 bg-emerald-50" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <div className={`inline-flex p-2 rounded-lg ${s.color} mb-3`}>{s.icon}</div>
            <p className="text-2xl font-bold text-slate-800">{s.value}</p>
            <p className="text-sm text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-slate-200">
        {(["overview", "entities", "users"] as const).map((t) => (
          <button key={t} onClick={() => setActiveTab(t)}
            className={`px-4 py-2 text-sm font-medium capitalize border-b-2 -mb-px transition ${activeTab === t ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500 hover:text-slate-700"}`}>
            {t}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
            <h2 className="font-semibold text-slate-800 mb-4">Risks per Entity</h2>
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={entityRiskCounts}>
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="risks" radius={[4,4,0,0]}>
                  {entityRiskCounts.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
            <h2 className="font-semibold text-slate-800 mb-4">National Risk Zone Summary</h2>
            <div className="space-y-3 mt-6">
              {zoneSummary.map((z) => (
                <div key={z.zone} className="flex items-center gap-3">
                  <span className="w-20 text-sm font-medium text-slate-700">{z.zone}</span>
                  <div className="flex-1 bg-slate-100 rounded-full h-4">
                    <div className="h-4 rounded-full transition-all"
                      style={{ width: allRisks.length ? `${(z.count / allRisks.length) * 100}%` : "0%", background: ZONE_COLORS[z.zone] }} />
                  </div>
                  <span className="w-8 text-sm font-bold text-slate-700 text-right">{z.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === "entities" && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Entity</th>
                <th className="text-left px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Assessed Unit</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Risks</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {entities.map((e) => {
                const eRisks = allRisks.filter((r) => r.entity_id === e.id);
                return (
                  <tr key={e.id} className="hover:bg-slate-50">
                    <td className="px-5 py-3 font-medium text-slate-800">{e.name}</td>
                    <td className="px-3 py-3 text-slate-500">{e.assessed_unit ?? "—"}</td>
                    <td className="px-3 py-3 text-center font-semibold">{eRisks.length}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold capitalize ${e.submission_status === "approved" ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-600"}`}>
                        {e.submission_status?.replace("_", " ") ?? "Draft"}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === "users" && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Name</th>
                <th className="text-left px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Email</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Role</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50">
                  <td className="px-5 py-3 font-medium text-slate-800">{u.full_name}</td>
                  <td className="px-3 py-3 text-slate-500">{u.email}</td>
                  <td className="px-3 py-3 text-center">
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                      {ROLE_LABELS[u.role] ?? u.role}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${u.is_active ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                      {u.is_active ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="px-3 py-3 text-center">
                    <button onClick={() => handleToggleUser(u.id)}
                      className={`px-3 py-1 text-xs font-semibold rounded-lg ${u.is_active ? "bg-red-100 text-red-700 hover:bg-red-200" : "bg-green-100 text-green-700 hover:bg-green-200"}`}>
                      {u.is_active ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
