import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import { riskApi, treatmentApi, kriApi, kpiApi, incidentApi, entityApi } from "../../api";
import {
  Shield, FileText, TrendingUp, BarChart2, AlertTriangle,
  CheckSquare, Activity, ChevronRight, Send, Clock
} from "lucide-react";

const ZONE_COLORS: Record<string, string> = {
  Low: "bg-green-100 text-green-800",
  Medium: "bg-yellow-100 text-yellow-800",
  High: "bg-orange-100 text-orange-800",
  Critical: "bg-red-100 text-red-800",
};

export default function RiskChampionDashboard() {
  const { user } = useAuth();
  const [risks, setRisks] = useState<any[]>([]);
  const [entity, setEntity] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.entity_id) { setLoading(false); return; }
    Promise.all([
      riskApi.list(user.entity_id),
      entityApi.get(user.entity_id),
    ]).then(([risksRes, entityRes]) => {
      setRisks(risksRes.data);
      setEntity(entityRes.data);
    }).finally(() => setLoading(false));
  }, [user?.entity_id]);

  const criticalCount = risks.filter((r) => r.rrl_zone === "Critical").length;
  const highCount = risks.filter((r) => r.rrl_zone === "High").length;
  const treatCount = risks.filter((r) => r.evaluation === "Treat").length;

  const statusColor: Record<string, string> = {
    draft: "bg-slate-100 text-slate-700",
    submitted: "bg-blue-100 text-blue-700",
    under_review: "bg-amber-100 text-amber-700",
    returned: "bg-red-100 text-red-700",
    approved: "bg-green-100 text-green-700",
  };

  const handleSubmit = async () => {
    if (!user?.entity_id) return;
    if (!confirm("Submit risk register to Risk Owner for review?")) return;
    await entityApi.submit(user.entity_id);
    const { data } = await entityApi.get(user.entity_id);
    setEntity(data);
  };

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;
  if (!user?.entity_id) return (
    <div className="text-center py-16 text-slate-500">
      <Shield className="w-12 h-12 mx-auto mb-3 text-slate-300" />
      <p className="font-medium">No entity assigned</p>
      <p className="text-sm mt-1">Contact your administrator to be assigned to an entity.</p>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">Risk Champion Dashboard</h1>
          <p className="text-slate-500 mt-0.5">
            {entity?.name} · {entity?.fiscal_year}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {entity?.submission_status && (
            <span className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${statusColor[entity.submission_status] ?? ""}`}>
              {entity.submission_status.replace("_", " ")}
            </span>
          )}
          {entity?.submission_status === "draft" && (
            <button
              onClick={handleSubmit}
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-blue-700 transition"
            >
              <Send className="w-4 h-4" />
              Submit for Review
            </button>
          )}
          {entity?.submission_status === "returned" && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-2 text-sm text-red-700">
              <strong>Returned:</strong> {entity.risk_owner_comments}
            </div>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Risks", value: risks.length, icon: <Shield className="w-5 h-5" />, color: "text-blue-600 bg-blue-50" },
          { label: "Critical", value: criticalCount, icon: <AlertTriangle className="w-5 h-5" />, color: "text-red-600 bg-red-50" },
          { label: "High", value: highCount, icon: <TrendingUp className="w-5 h-5" />, color: "text-orange-600 bg-orange-50" },
          { label: "To Treat", value: treatCount, icon: <Activity className="w-5 h-5" />, color: "text-violet-600 bg-violet-50" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <div className={`inline-flex p-2 rounded-lg ${s.color} mb-3`}>{s.icon}</div>
            <p className="text-2xl font-bold text-slate-800">{s.value}</p>
            <p className="text-sm text-slate-500">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <h2 className="font-semibold text-slate-800 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { label: "Risk Register", path: "/risks", icon: <Shield className="w-5 h-5 text-blue-600" />, desc: "Manage risk events" },
            { label: "Treatment Plans", path: "/treatment-plans", icon: <FileText className="w-5 h-5 text-violet-600" />, desc: "Improvement actions" },
            { label: "KRIs", path: "/kris", icon: <TrendingUp className="w-5 h-5 text-emerald-600" />, desc: "Key risk indicators" },
            { label: "KPIs", path: "/kpis", icon: <BarChart2 className="w-5 h-5 text-amber-600" />, desc: "Performance indicators" },
            { label: "Compliance", path: "/compliance", icon: <CheckSquare className="w-5 h-5 text-sky-600" />, desc: "Control compliance" },
            { label: "Incidents", path: "/incidents", icon: <AlertTriangle className="w-5 h-5 text-red-600" />, desc: "Incident management" },
          ].map((a) => (
            <Link key={a.path} to={a.path}
              className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 hover:bg-slate-50 hover:border-blue-300 transition-colors"
            >
              <div className="mt-0.5">{a.icon}</div>
              <div>
                <p className="text-sm font-semibold text-slate-700">{a.label}</p>
                <p className="text-xs text-slate-400">{a.desc}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Risks */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-slate-800">Risk Register Summary</h2>
          <Link to="/risks" className="text-blue-600 text-sm hover:underline flex items-center gap-1">
            View all <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Risk Event</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">IRL</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">RRL</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Zone</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Evaluation</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {risks.slice(0, 8).map((r) => (
                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3 text-slate-700 max-w-xs truncate">{r.risk_event}</td>
                  <td className="px-3 py-3 text-center font-semibold">{r.irl ?? "—"}</td>
                  <td className="px-3 py-3 text-center font-semibold">{r.rrl ?? "—"}</td>
                  <td className="px-3 py-3 text-center">
                    {r.rrl_zone ? (
                      <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${ZONE_COLORS[r.rrl_zone] ?? ""}`}>
                        {r.rrl_zone}
                      </span>
                    ) : "—"}
                  </td>
                  <td className="px-3 py-3 text-center">
                    <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${r.evaluation === "Treat" ? "bg-orange-100 text-orange-700" : "bg-green-100 text-green-700"}`}>
                      {r.evaluation ?? "—"}
                    </span>
                  </td>
                </tr>
              ))}
              {risks.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-slate-400">
                    No risks recorded yet. <Link to="/risks" className="text-blue-600 underline">Add a risk</Link>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
