import { useEffect, useState } from "react";
import { entityApi, riskApi } from "../../api";
import { Building2, AlertTriangle, CheckCircle, Clock, ChevronRight, FileDown } from "lucide-react";
import { Link } from "react-router-dom";

const STATUS_CONFIG: Record<string, { label: string; color: string }> = {
  draft: { label: "Draft", color: "bg-slate-100 text-slate-600" },
  submitted: { label: "Submitted", color: "bg-blue-100 text-blue-700" },
  under_review: { label: "Under Review", color: "bg-amber-100 text-amber-700" },
  returned: { label: "Returned", color: "bg-red-100 text-red-700" },
  approved: { label: "Approved", color: "bg-green-100 text-green-700" },
};

export default function CoordinatorDashboard() {
  const [entities, setEntities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    entityApi.list().then((r) => setEntities(r.data)).finally(() => setLoading(false));
  }, []);

  const submitted = entities.filter((e) => e.submission_status === "submitted").length;
  const approved = entities.filter((e) => e.submission_status === "approved").length;
  const pending = entities.filter((e) => ["draft", "returned"].includes(e.submission_status)).length;

  if (loading) return <div className="text-slate-500 py-8 text-center">Loading...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Coordinator Dashboard</h1>
        <p className="text-slate-500 mt-0.5">Consolidate risk reports from all entities</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Entities", value: entities.length, color: "text-blue-600" },
          { label: "Submitted", value: submitted, color: "text-amber-600" },
          { label: "Approved", value: approved, color: "text-green-600" },
          { label: "Pending", value: pending, color: "text-red-600" },
        ].map((s) => (
          <div key={s.label} className="bg-white rounded-xl p-5 shadow-sm border border-slate-200">
            <p className={`text-3xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-sm text-slate-500 mt-1">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-5">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-slate-800">Consolidation Progress</h2>
          <span className="text-sm text-slate-500">{approved}/{entities.length} approved</span>
        </div>
        <div className="w-full bg-slate-100 rounded-full h-3">
          <div
            className="bg-green-500 h-3 rounded-full transition-all"
            style={{ width: entities.length ? `${(approved / entities.length) * 100}%` : "0%" }}
          />
        </div>
        <p className="text-xs text-slate-400 mt-2">
          {submitted} entities awaiting Coordinator review before forwarding to RMC
        </p>
      </div>

      {/* Entities table */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <h2 className="font-semibold text-slate-800">Entities Status</h2>
          <Link to="/entities" className="text-blue-600 text-sm hover:underline flex items-center gap-1">
            Manage <ChevronRight className="w-3 h-3" />
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="text-left px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Entity</th>
                <th className="text-left px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Assessed Unit</th>
                <th className="text-left px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Fiscal Year</th>
                <th className="text-center px-3 py-3 text-xs font-semibold text-slate-500 uppercase">Status</th>
                <th className="text-right px-5 py-3 text-xs font-semibold text-slate-500 uppercase">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {entities.map((e) => {
                const sc = STATUS_CONFIG[e.submission_status ?? "draft"];
                return (
                  <tr key={e.id} className="hover:bg-slate-50">
                    <td className="px-5 py-3 font-medium text-slate-800">{e.name}</td>
                    <td className="px-3 py-3 text-slate-500">{e.assessed_unit ?? "—"}</td>
                    <td className="px-3 py-3 text-slate-500">{e.fiscal_year}</td>
                    <td className="px-3 py-3 text-center">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${sc.color}`}>{sc.label}</span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <Link to={`/entities/${e.id}`} className="text-blue-600 text-xs hover:underline">View risks →</Link>
                    </td>
                  </tr>
                );
              })}
              {entities.length === 0 && (
                <tr><td colSpan={5} className="px-5 py-8 text-center text-slate-400">No entities found.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
