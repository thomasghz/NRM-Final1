import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { authApi } from "../api";

export type UserRole =
  | "risk_champion"
  | "risk_owner"
  | "coordinator"
  | "rmc"
  | "senior_management"
  | "minecofin";

export interface AuthUser {
  id: string;
  full_name: string;
  email: string;
  role: UserRole;
  entity_id: string | null;
}

interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(
    () => localStorage.getItem("nrm_token")
  );
  const [user, setUser] = useState<AuthUser | null>(() => {
    const stored = localStorage.getItem("nrm_user");
    return stored ? JSON.parse(stored) : null;
  });

  const login = useCallback(async (email: string, password: string) => {
    const { data } = await authApi.login(email, password);
    setToken(data.access_token);
    setUser(data.user);
    localStorage.setItem("nrm_token", data.access_token);
    localStorage.setItem("nrm_user", JSON.stringify(data.user));
  }, []);

  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
    localStorage.removeItem("nrm_token");
    localStorage.removeItem("nrm_user");
  }, []);

  return (
    <AuthContext.Provider value={{ user, token, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}

export const ROLE_LABELS: Record<UserRole, string> = {
  risk_champion: "Risk Champion",
  risk_owner: "Risk Owner",
  coordinator: "Coordinator",
  rmc: "Risk Management Committee",
  senior_management: "Senior Management",
  minecofin: "MINECOFIN",
};
