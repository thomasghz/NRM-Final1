"""Add users table; rename departments to entities; add submission workflow fields

Revision ID: 0002
Revises: 0001
Create Date: 2025-01-01
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

USER_ROLE_ENUM = postgresql.ENUM(
    "risk_champion", "risk_owner", "coordinator", "rmc",
    "senior_management", "minecofin",
    name="userrole",
)
SUBMISSION_STATUS_ENUM = postgresql.ENUM(
    "draft", "submitted", "under_review", "returned", "approved",
    name="submissionstatus",
)


def upgrade() -> None:
    # ── Create enums ────────────────────────────────────────────────────────
    USER_ROLE_ENUM.create(op.get_bind(), checkfirst=True)
    SUBMISSION_STATUS_ENUM.create(op.get_bind(), checkfirst=True)

    # ── Rename departments → entities ───────────────────────────────────────
    op.rename_table("departments", "entities")

    # Rename FK column in critical_success_factors
    op.alter_column("critical_success_factors", "department_id",
                    new_column_name="entity_id")
    # Rename FK column in risks
    op.alter_column("risks", "department_id", new_column_name="entity_id")
    # Rename FK column in kpis
    op.alter_column("kpis", "department_id", new_column_name="entity_id")
    # Rename FK column in incidents
    op.alter_column("incidents", "department_id", new_column_name="entity_id")

    # ── Add workflow columns to entities ────────────────────────────────────
    op.add_column("entities", sa.Column(
        "submission_status",
        SUBMISSION_STATUS_ENUM,
        server_default="draft",
        nullable=True,
    ))
    op.add_column("entities", sa.Column("risk_owner_comments", sa.Text(), nullable=True))

    # ── Create users table ──────────────────────────────────────────────────
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True,
                  server_default=sa.text("gen_random_uuid()")),
        sa.Column("full_name", sa.String(255), nullable=False),
        sa.Column("email", sa.String(255), nullable=False, unique=True),
        sa.Column("hashed_password", sa.String(255), nullable=False),
        sa.Column("role", USER_ROLE_ENUM, nullable=False, server_default="risk_champion"),
        sa.Column("entity_id", postgresql.UUID(as_uuid=True),
                  sa.ForeignKey("entities.id", ondelete="SET NULL"), nullable=True),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)


def downgrade() -> None:
    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")

    op.drop_column("entities", "risk_owner_comments")
    op.drop_column("entities", "submission_status")

    op.alter_column("incidents", "entity_id", new_column_name="department_id")
    op.alter_column("kpis", "entity_id", new_column_name="department_id")
    op.alter_column("risks", "entity_id", new_column_name="department_id")
    op.alter_column("critical_success_factors", "entity_id", new_column_name="department_id")

    op.rename_table("entities", "departments")

    SUBMISSION_STATUS_ENUM.drop(op.get_bind(), checkfirst=True)
    USER_ROLE_ENUM.drop(op.get_bind(), checkfirst=True)
