-- =============================================================================
-- NRM SYSTEM — STEP 1: CREATE DATABASE & USER
-- Run this as a PostgreSQL superuser (postgres):
--
--   psql -U postgres -f nrm_create_db.sql
--
-- After this script completes, run Step 2:
--   psql -U postgres -d nrm_db -f nrm_schema.sql
-- =============================================================================

-- Create application user (skip if already exists)
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'nrm_user') THEN
    CREATE USER nrm_user WITH PASSWORD 'nrm_pass';
    RAISE NOTICE 'User nrm_user created.';
  ELSE
    RAISE NOTICE 'User nrm_user already exists — skipping.';
  END IF;
END
$$;

-- Create database (skip if already exists)
SELECT 'CREATE DATABASE nrm_db OWNER nrm_user ENCODING ''UTF8'''
  WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = 'nrm_db')
\gexec

-- Grant full privileges
GRANT ALL PRIVILEGES ON DATABASE nrm_db TO nrm_user;

\echo ''
\echo 'Step 1 complete. Now run:'
\echo '  psql -U postgres -d nrm_db -f nrm_schema.sql'
\echo ''