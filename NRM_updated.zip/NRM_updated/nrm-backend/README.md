# NRM Backend API v2.0

## What's New in v2.0
- **JWT Authentication** — email/password login with Bearer tokens
- **Role-Based Access Control** — 6 roles with distinct permissions
- **"Department" renamed to "Entity"** throughout the entire codebase
- **Submission Workflow** — Risk Champion → Risk Owner → Coordinator → RMC → Senior Management → MINECOFIN

## User Roles

| Role | Access |
|------|--------|
| `risk_champion` | Data entry for their assigned entity (risks, treatment plans, KRIs, KPIs, compliance, incidents) |
| `risk_owner` | Reviews and forwards the risk register; can return for revision |
| `coordinator` | Consolidates risk-in-motion from all entities; submits to RMC |
| `rmc` | Reviews consolidated reports; approves or returns; submits to Senior Management |
| `senior_management` | Views top-risk reports; gives final entity approval |
| `minecofin` | National view of all entities; user management; consolidated analytics |

## Quick Start

```bash
# 1. Copy env
cp .env.example .env
# Edit .env with your DB credentials and a strong SECRET_KEY

# 2. Install deps
pip install -r requirements.txt

# 3. Run migrations
alembic upgrade head

# 4. Start server
uvicorn app.main:app --reload

# API docs at http://localhost:8000/docs
```

## Auth Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/register` | Register a new user |
| POST | `/auth/login` | Login (returns JWT) |
| GET | `/auth/me` | Current user info |
| GET | `/auth/users` | List users (Coordinator/RMC/MINECOFIN) |
| PUT | `/auth/users/{id}/toggle` | Activate/deactivate user (MINECOFIN only) |

## Entity Endpoints (formerly /departments)

All endpoints now use `/entities` prefix. The `department_id` field is now `entity_id`.
