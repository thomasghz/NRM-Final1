from datetime import timedelta
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from pydantic import BaseModel, EmailStr
from typing import Optional
from uuid import UUID

from app.database import get_db
from app.models.models import User, UserRole
from app.services.auth_service import (
    hash_password, verify_password,
    create_access_token, get_current_user,
)
from app.config import settings

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ── Schemas (inline for self-containment) ──────────────────────────────────

class RegisterRequest(BaseModel):
    full_name: str
    email: str
    password: str
    role: UserRole
    entity_id: Optional[UUID] = None


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: dict


class UserOut(BaseModel):
    id: UUID
    full_name: str
    email: str
    role: UserRole
    entity_id: Optional[UUID]
    is_active: bool

    model_config = {"from_attributes": True}


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post("/register", response_model=UserOut, status_code=201)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(400, "Email already registered")
    user = User(
        full_name=payload.full_name,
        email=payload.email,
        hashed_password=hash_password(payload.password),
        role=payload.role,
        entity_id=payload.entity_id,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenResponse)
def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db),
):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is disabled")

    token = create_access_token(
        data={"sub": str(user.id), "role": user.role.value},
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    return {
        "access_token": token,
        "token_type": "bearer",
        "user": {
            "id": str(user.id),
            "full_name": user.full_name,
            "email": user.email,
            "role": user.role.value,
            "entity_id": str(user.entity_id) if user.entity_id else None,
        },
    }


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("/users", response_model=list[UserOut])
def list_users(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Only MINECOFIN / RMC / Coordinator can list all users."""
    allowed = {UserRole.MINECOFIN, UserRole.RMC, UserRole.COORDINATOR}
    if current_user.role not in allowed:
        raise HTTPException(403, "Not authorized")
    return db.query(User).all()


@router.put("/users/{user_id}/toggle", response_model=UserOut)
def toggle_user(
    user_id: UUID,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """MINECOFIN can activate/deactivate users."""
    if current_user.role != UserRole.MINECOFIN:
        raise HTTPException(403, "Not authorized")
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.is_active = not user.is_active
    db.commit()
    db.refresh(user)
    return user
