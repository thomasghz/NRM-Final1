from uuid import UUID
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload

from app.database import get_db
from app.models.models import Entity, CriticalSuccessFactor, User, UserRole
from app.schemas.schemas import EntityCreate, EntityUpdate, EntityOut, CSFCreate, CSFOut
from app.services.auth_service import get_current_user

router = APIRouter(prefix="/entities", tags=["Entities"])


@router.post("", response_model=EntityOut, status_code=201)
def create_entity(
    payload: EntityCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    allowed = {UserRole.COORDINATOR, UserRole.MINECOFIN, UserRole.RMC}
    if current_user.role not in allowed:
        raise HTTPException(403, "Only Coordinator / MINECOFIN / RMC can create entities")
    entity = Entity(
        name=payload.name,
        assessed_unit=payload.assessed_unit,
        objective=payload.objective,
        fiscal_year=payload.fiscal_year,
    )
    db.add(entity)
    db.flush()
    for csf_data in (payload.csfs or []):
        csf = CriticalSuccessFactor(
            entity_id=entity.id,
            pillar=csf_data.pillar,
            characteristics=csf_data.characteristics,
        )
        db.add(csf)
    db.commit()
    db.refresh(entity)
    return entity


@router.get("", response_model=list[EntityOut])
def list_entities(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    q = db.query(Entity).options(joinedload(Entity.csfs))
    # Risk Champion / Risk Owner only see their own entity
    if current_user.role in {UserRole.RISK_CHAMPION, UserRole.RISK_OWNER}:
        if current_user.entity_id:
            q = q.filter(Entity.id == current_user.entity_id)
        else:
            return []
    return q.all()


@router.get("/{entity_id}", response_model=EntityOut)
def get_entity(
    entity_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entity = (
        db.query(Entity)
        .options(joinedload(Entity.csfs))
        .filter(Entity.id == entity_id)
        .first()
    )
    if not entity:
        raise HTTPException(404, "Entity not found")
    # Scope check
    if current_user.role in {UserRole.RISK_CHAMPION, UserRole.RISK_OWNER}:
        if current_user.entity_id != entity_id:
            raise HTTPException(403, "Access denied to this entity")
    return entity


@router.put("/{entity_id}", response_model=EntityOut)
def update_entity(
    entity_id: UUID,
    payload: EntityUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entity = db.query(Entity).filter(Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(404, "Entity not found")
    for field, val in payload.model_dump(exclude_none=True).items():
        setattr(entity, field, val)
    db.commit()
    db.refresh(entity)
    return entity


@router.delete("/{entity_id}", status_code=204)
def delete_entity(
    entity_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role not in {UserRole.MINECOFIN, UserRole.COORDINATOR}:
        raise HTTPException(403, "Not authorized")
    entity = db.query(Entity).filter(Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(404, "Entity not found")
    db.delete(entity)
    db.commit()


@router.post("/{entity_id}/csfs", response_model=CSFOut, status_code=201)
def add_csf(
    entity_id: UUID,
    payload: CSFCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    entity = db.query(Entity).filter(Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(404, "Entity not found")
    csf = CriticalSuccessFactor(entity_id=entity_id, **payload.model_dump())
    db.add(csf)
    db.commit()
    db.refresh(csf)
    return csf


@router.post("/{entity_id}/submit", response_model=EntityOut)
def submit_for_review(
    entity_id: UUID,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Risk Champion submits risk register to Risk Owner."""
    from app.models.models import SubmissionStatus
    if current_user.role != UserRole.RISK_CHAMPION:
        raise HTTPException(403, "Only Risk Champions can submit")
    entity = db.query(Entity).filter(Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(404, "Entity not found")
    entity.submission_status = SubmissionStatus.SUBMITTED
    db.commit()
    db.refresh(entity)
    return entity


@router.post("/{entity_id}/review", response_model=EntityOut)
def risk_owner_review(
    entity_id: UUID,
    payload: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Risk Owner reviews and either approves or returns."""
    from app.models.models import SubmissionStatus
    if current_user.role != UserRole.RISK_OWNER:
        raise HTTPException(403, "Only Risk Owners can review")
    entity = db.query(Entity).filter(Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(404, "Entity not found")
    action = payload.get("action")  # "approve" | "return"
    entity.risk_owner_comments = payload.get("comments", "")
    entity.submission_status = (
        SubmissionStatus.UNDER_REVIEW if action == "approve" else SubmissionStatus.RETURNED
    )
    db.commit()
    db.refresh(entity)
    return entity
