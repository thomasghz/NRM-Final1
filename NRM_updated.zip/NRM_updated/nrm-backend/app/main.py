from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import (
    risks, treatment_plans,
    kris, kpis, compliance, incidents,
    aggregation, export,
)
from app.routers import entities
from app.routers import auth

app = FastAPI(
    title="National Risk Management System API",
    description=(
        "Backend API for the NRM System — manages risks, KRIs, KPIs, "
        "compliance controls, incidents, and generates Excel reports. "
        "Includes JWT authentication with role-based access control."
    ),
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ---------------------------------------------------------------------------
# CORS
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Routers
# ---------------------------------------------------------------------------
app.include_router(auth.router)
app.include_router(entities.router)
app.include_router(risks.router)
app.include_router(treatment_plans.router)
app.include_router(kris.router)
app.include_router(kpis.router)
app.include_router(compliance.router)
app.include_router(incidents.router)
app.include_router(aggregation.router)
app.include_router(export.router)


@app.get("/", tags=["Health"])
def root():
    return {
        "service": "NRM Backend API",
        "version": "2.0.0",
        "docs": "/docs",
    }


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
