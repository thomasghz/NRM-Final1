-- =============================================================================
-- NRM SYSTEM — STEP 2: SCHEMA, INDEXES, TRIGGERS & SEED DATA
-- Run this AFTER Step 1, connected directly to nrm_db:
--
--   psql -U postgres -d nrm_db -f nrm_schema.sql
--
-- This script is safe to re-run (uses IF NOT EXISTS throughout).
-- =============================================================================


-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "pgcrypto";


-- =============================================================================
-- PART 1: REFERENCE / LOOKUP TABLES
-- =============================================================================

CREATE TABLE IF NOT EXISTS likelihood_scale (
    level        INTEGER     PRIMARY KEY CHECK (level BETWEEN 1 AND 5),
    label        VARCHAR(50) NOT NULL,
    description  TEXT
);

CREATE TABLE IF NOT EXISTS consequence_scale (
    severity         INTEGER     PRIMARY KEY CHECK (severity BETWEEN 1 AND 5),
    label            VARCHAR(50) NOT NULL,
    financial        TEXT,
    reputation       TEXT,
    human_capital    TEXT,
    service_delivery TEXT,
    regulatory       TEXT,
    projects         TEXT,
    info_systems     TEXT
);

CREATE TABLE IF NOT EXISTS risk_acceptance_criteria (
    id          SERIAL      PRIMARY KEY,
    score_min   INTEGER     NOT NULL,
    score_max   INTEGER     NOT NULL,
    zone        VARCHAR(20) NOT NULL,
    action      VARCHAR(60) NOT NULL,
    colour_hex  CHAR(6)
);


-- =============================================================================
-- PART 2: CORE ENTITIES  (in foreign-key dependency order)
-- =============================================================================

-- ---------------------------------------------------------------------------
-- Departments
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS departments (
    id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    name           VARCHAR(255) NOT NULL,
    assessed_unit  VARCHAR(255),
    objective      TEXT,
    fiscal_year    VARCHAR(20)  NOT NULL DEFAULT '2025/2026',
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Critical Success Factors
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS critical_success_factors (
    id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    department_id  UUID        NOT NULL
                               REFERENCES departments(id) ON DELETE CASCADE,
    pillar         VARCHAR(255) NOT NULL,
    characteristics TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Risks
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS risks (
    id             UUID  PRIMARY KEY DEFAULT gen_random_uuid(),
    department_id  UUID  NOT NULL REFERENCES departments(id)              ON DELETE CASCADE,
    csf_id         UUID  REFERENCES critical_success_factors(id)         ON DELETE SET NULL,

    risk_event     TEXT  NOT NULL,
    risk_source    TEXT,
    risk_effect    TEXT,

    -- Inherent risk (1–5 per dimension)
    likelihood_i            INTEGER CHECK (likelihood_i            BETWEEN 1 AND 5),
    financial_i             INTEGER CHECK (financial_i             BETWEEN 1 AND 5),
    reputation_i            INTEGER CHECK (reputation_i            BETWEEN 1 AND 5),
    human_capital_i         INTEGER CHECK (human_capital_i         BETWEEN 1 AND 5),
    service_delivery_i      INTEGER CHECK (service_delivery_i      BETWEEN 1 AND 5),
    regulatory_i            INTEGER CHECK (regulatory_i            BETWEEN 1 AND 5),
    projects_i              INTEGER CHECK (projects_i              BETWEEN 1 AND 5),
    info_systems_i          INTEGER CHECK (info_systems_i          BETWEEN 1 AND 5),
    overall_inherent_consequence  INTEGER,
    irl                           INTEGER,

    current_controls  TEXT,

    -- Residual risk (1–5 per dimension)
    likelihood_r            INTEGER CHECK (likelihood_r            BETWEEN 1 AND 5),
    financial_r             INTEGER CHECK (financial_r             BETWEEN 1 AND 5),
    reputation_r            INTEGER CHECK (reputation_r            BETWEEN 1 AND 5),
    human_capital_r         INTEGER CHECK (human_capital_r         BETWEEN 1 AND 5),
    service_delivery_r      INTEGER CHECK (service_delivery_r      BETWEEN 1 AND 5),
    regulatory_r            INTEGER CHECK (regulatory_r            BETWEEN 1 AND 5),
    projects_r              INTEGER CHECK (projects_r              BETWEEN 1 AND 5),
    info_systems_r          INTEGER CHECK (info_systems_r          BETWEEN 1 AND 5),
    overall_residual_consequence  INTEGER,
    rrl                           INTEGER,

    evaluation  VARCHAR(10) CHECK (evaluation IN ('Accept', 'Treat')),

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- Treatment Plans
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS treatment_plans (
    id                 UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    risk_id            UUID        NOT NULL REFERENCES risks(id) ON DELETE CASCADE,

    improvement_action TEXT        NOT NULL,
    due_date           DATE,
    responsibility     VARCHAR(255),

    q1_status          VARCHAR(50) CHECK (q1_status IN ('Not Started','WIP','Completed','Overdue','Select one')),
    q1_comments        TEXT,
    q1_further_action  TEXT,

    q2_status          VARCHAR(50) CHECK (q2_status IN ('Not Started','WIP','Completed','Overdue','Select one')),
    q2_comments        TEXT,
    q2_further_action  TEXT,

    q3_status          VARCHAR(50) CHECK (q3_status IN ('Not Started','WIP','Completed','Overdue','Select one')),
    q3_comments        TEXT,
    q3_further_action  TEXT,

    q4_status          VARCHAR(50) CHECK (q4_status IN ('Not Started','WIP','Completed','Overdue','Select one')),
    q4_comments        TEXT,
    q4_further_action  TEXT,

    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------------------------------------------------------------------------
-- KRIs
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kris (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    risk_id          UUID          NOT NULL REFERENCES risks(id) ON DELETE CASCADE,
    description      TEXT          NOT NULL,
    frequency        VARCHAR(50),
    green_threshold  NUMERIC(10,2) NOT NULL,
    amber_threshold  NUMERIC(10,2) NOT NULL,
    direction        VARCHAR(20)   NOT NULL DEFAULT 'lower_is_better',
    responsibility   VARCHAR(255),
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_kri_frequency
        CHECK (frequency IN ('Monthly','Quarterly','Annually') OR frequency IS NULL),
    CONSTRAINT chk_kri_direction
        CHECK (direction IN ('lower_is_better','higher_is_better'))
);

CREATE TABLE IF NOT EXISTS kri_entries (
    id                     UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    kri_id                 UUID          NOT NULL REFERENCES kris(id) ON DELETE CASCADE,
    quarter                VARCHAR(10)   NOT NULL,
    entry_value            NUMERIC(10,2),
    status                 VARCHAR(10),
    comments               TEXT,
    action_taken           TEXT,
    due_date               DATE,
    responsibility         VARCHAR(255),
    previous_action_status VARCHAR(50),
    created_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_kri_entry_quarter  UNIQUE (kri_id, quarter),
    CONSTRAINT chk_kri_entry_quarter CHECK (quarter IN ('Q1','Q2','Q3','Q4')),
    CONSTRAINT chk_kri_entry_status  CHECK (status IN ('Green','Amber','Red') OR status IS NULL)
);

-- ---------------------------------------------------------------------------
-- KPIs
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kpis (
    id               UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    department_id    UUID          NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    description      TEXT          NOT NULL,
    frequency        VARCHAR(50),
    green_threshold  NUMERIC(10,2) NOT NULL,
    amber_threshold  NUMERIC(10,2) NOT NULL,
    direction        VARCHAR(20)   NOT NULL DEFAULT 'higher_is_better',
    responsibility   VARCHAR(255),
    created_at       TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_kpi_frequency
        CHECK (frequency IN ('Monthly','Quarterly','Annually') OR frequency IS NULL),
    CONSTRAINT chk_kpi_direction
        CHECK (direction IN ('lower_is_better','higher_is_better'))
);

CREATE TABLE IF NOT EXISTS kpi_entries (
    id             UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    kpi_id         UUID          NOT NULL REFERENCES kpis(id) ON DELETE CASCADE,
    quarter        VARCHAR(10)   NOT NULL,
    entry_value    NUMERIC(10,2),
    status         VARCHAR(10),
    comments       TEXT,
    action_taken   TEXT,
    due_date       DATE,
    responsibility VARCHAR(255),
    created_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ   NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_kpi_entry_quarter  UNIQUE (kpi_id, quarter),
    CONSTRAINT chk_kpi_entry_quarter CHECK (quarter IN ('Q1','Q2','Q3','Q4')),
    CONSTRAINT chk_kpi_entry_status  CHECK (status IN ('Green','Amber','Red') OR status IS NULL)
);

-- ---------------------------------------------------------------------------
-- Compliance Controls & Entries
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS compliance_controls (
    id                   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    risk_id              UUID        NOT NULL REFERENCES risks(id) ON DELETE CASCADE,
    key_control          TEXT        NOT NULL,
    compliance_question  TEXT,
    frequency            VARCHAR(50),
    responsibility       VARCHAR(255),
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_compliance_frequency
        CHECK (frequency IN ('Monthly','Quarterly','Annually') OR frequency IS NULL)
);

CREATE TABLE IF NOT EXISTS compliance_entries (
    id               UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    compliance_id    UUID        NOT NULL REFERENCES compliance_controls(id) ON DELETE CASCADE,
    quarter          VARCHAR(10) NOT NULL,
    response         VARCHAR(10),
    comments_for_no  TEXT,
    action_taken     TEXT,
    due_date         DATE,
    responsibility   VARCHAR(255),
    status           VARCHAR(50),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_compliance_entry_quarter  UNIQUE (compliance_id, quarter),
    CONSTRAINT chk_compliance_entry_quarter CHECK (quarter IN ('Q1','Q2','Q3','Q4')),
    CONSTRAINT chk_compliance_response      CHECK (response IN ('Yes','No') OR response IS NULL),
    CONSTRAINT chk_compliance_status        CHECK (status IN ('WIP','Completed','Select one') OR status IS NULL),
    -- Business rule: comments_for_no is required when response = 'No'
    CONSTRAINT chk_no_requires_comment
        CHECK (response IS DISTINCT FROM 'No' OR (comments_for_no IS NOT NULL AND comments_for_no <> ''))
);

-- ---------------------------------------------------------------------------
-- Incidents
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS incidents (
    id                        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    department_id             UUID        NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    risk_id                   UUID        REFERENCES risks(id)               ON DELETE SET NULL,

    serial_no                 INTEGER,
    quarter                   VARCHAR(10),
    details                   TEXT,
    incident_date             DATE,
    location                  VARCHAR(255),
    direct_financial_impact   BOOLEAN     NOT NULL DEFAULT FALSE,
    non_financial_impact      TEXT,
    action_taken              TEXT,
    risk_causes               TEXT,
    risk_effects              TEXT,
    control_failed            TEXT,
    corrective_action         TEXT,
    case_summary_done         BOOLEAN     NOT NULL DEFAULT FALSE,
    managers_comments         TEXT,
    further_corrective_action TEXT,
    due_date                  DATE,
    created_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_incident_quarter CHECK (quarter IN ('Q1','Q2','Q3','Q4') OR quarter IS NULL)
);

-- ---------------------------------------------------------------------------
-- Risk Aggregation
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS risk_aggregation (
    id                  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    risk_id             UUID        NOT NULL REFERENCES risks(id) ON DELETE CASCADE,
    quarter             VARCHAR(10) NOT NULL,
    aggregate_ranking   INTEGER,
    movement            VARCHAR(5),
    risk_owner_comments TEXT,
    action_being_taken  TEXT,
    due_date            DATE,
    responsible_person  VARCHAR(255),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_aggregation_risk_quarter UNIQUE (risk_id, quarter),
    CONSTRAINT chk_aggregation_quarter     CHECK (quarter IN ('Q1','Q2','Q3','Q4')),
    CONSTRAINT chk_aggregate_ranking       CHECK (aggregate_ranking >= 1 OR aggregate_ranking IS NULL)
);


-- =============================================================================
-- PART 3: INDEXES
-- =============================================================================

CREATE INDEX IF NOT EXISTS idx_risks_department_id          ON risks(department_id);
CREATE INDEX IF NOT EXISTS idx_csf_department_id            ON critical_success_factors(department_id);
CREATE INDEX IF NOT EXISTS idx_treatment_plans_risk_id      ON treatment_plans(risk_id);
CREATE INDEX IF NOT EXISTS idx_kris_risk_id                 ON kris(risk_id);
CREATE INDEX IF NOT EXISTS idx_kri_entries_kri_id           ON kri_entries(kri_id);
CREATE INDEX IF NOT EXISTS idx_kri_entries_quarter          ON kri_entries(quarter);
CREATE INDEX IF NOT EXISTS idx_kpis_department_id           ON kpis(department_id);
CREATE INDEX IF NOT EXISTS idx_kpi_entries_kpi_id           ON kpi_entries(kpi_id);
CREATE INDEX IF NOT EXISTS idx_kpi_entries_quarter          ON kpi_entries(quarter);
CREATE INDEX IF NOT EXISTS idx_compliance_controls_risk_id  ON compliance_controls(risk_id);
CREATE INDEX IF NOT EXISTS idx_compliance_entries_ctrl_id   ON compliance_entries(compliance_id);
CREATE INDEX IF NOT EXISTS idx_compliance_entries_quarter   ON compliance_entries(quarter);
CREATE INDEX IF NOT EXISTS idx_incidents_department_id      ON incidents(department_id);
CREATE INDEX IF NOT EXISTS idx_incidents_risk_id            ON incidents(risk_id);
CREATE INDEX IF NOT EXISTS idx_incidents_quarter            ON incidents(quarter);
CREATE INDEX IF NOT EXISTS idx_risk_aggregation_risk_id     ON risk_aggregation(risk_id);
CREATE INDEX IF NOT EXISTS idx_risk_aggregation_quarter     ON risk_aggregation(quarter);


-- =============================================================================
-- PART 4: AUTO-UPDATE updated_at TRIGGER
-- =============================================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger on each table that has updated_at.
-- Uses IF EXISTS check to be safe on re-runs.
DO $$
DECLARE
    tbl TEXT;
BEGIN
    FOREACH tbl IN ARRAY ARRAY[
        'departments',
        'risks',
        'treatment_plans',
        'kri_entries',
        'kpi_entries',
        'compliance_entries',
        'incidents',
        'risk_aggregation'
    ]
    LOOP
        -- Only create the trigger if the table exists in this schema
        IF EXISTS (
            SELECT 1 FROM pg_tables
            WHERE schemaname = 'public' AND tablename = tbl
        ) THEN
            EXECUTE format(
                'DROP TRIGGER IF EXISTS trg_set_updated_at ON %I;
                 CREATE TRIGGER trg_set_updated_at
                 BEFORE UPDATE ON %I
                 FOR EACH ROW EXECUTE FUNCTION set_updated_at();',
                tbl, tbl
            );
            RAISE NOTICE 'Trigger created on table: %', tbl;
        ELSE
            RAISE WARNING 'Table % not found — trigger skipped.', tbl;
        END IF;
    END LOOP;
END;
$$;


-- =============================================================================
-- PART 5: SEED REFERENCE DATA
-- =============================================================================

INSERT INTO likelihood_scale (level, label, description) VALUES
    (1, 'Rare',           'May occur only in exceptional circumstances (<10%)'),
    (2, 'Unlikely',       'Could occur at some time (10–30%)'),
    (3, 'Possible',       'Might occur at some time (30–50%)'),
    (4, 'Likely',         'Will probably occur in most circumstances (50–70%)'),
    (5, 'Almost Certain', 'Expected to occur in most circumstances (>70%)')
ON CONFLICT (level) DO NOTHING;

INSERT INTO consequence_scale
    (severity, label, financial, reputation, human_capital, service_delivery, regulatory, projects, info_systems)
VALUES
    (1, 'Insignificant',
        'Negligible loss (<0.1% budget)',
        'Minor internal criticism only',
        'No injury or illness',
        'Brief disruption < 1 day',
        'Minor breach, no penalty',
        'Minor delay < 1 week',
        'Minimal data loss, recoverable within hours'),
    (2, 'Minor',
        'Minor loss (0.1–1% budget)',
        'Limited external criticism',
        'First-aid treatment only',
        'Disruption 1–3 days',
        'Regulatory notice, no fine',
        'Schedule slip 1–4 weeks',
        'Some data loss, recoverable in 1 day'),
    (3, 'Moderate',
        'Significant loss (1–5% budget)',
        'Negative media coverage',
        'Medical treatment, lost time',
        'Disruption 3–14 days',
        'Formal investigation, potential fine',
        'Slip 1–3 months, overrun 5–15%',
        'Major data loss, recovery takes days'),
    (4, 'Major',
        'Major loss (5–20% budget)',
        'Sustained negative media',
        'Serious injury possible',
        'Disruption > 2 weeks',
        'Regulatory sanction, significant fine',
        'Project failure, overrun > 15%',
        'Critical failure, recovery > 1 week'),
    (5, 'Catastrophic',
        'Critical loss (> 20% budget)',
        'Loss of public confidence',
        'Fatality or multiple serious injuries',
        'Full service collapse',
        'Criminal prosecution / licence revoked',
        'Programme collapse, complete write-off',
        'Permanent/unrecoverable data loss')
ON CONFLICT (severity) DO NOTHING;

INSERT INTO risk_acceptance_criteria (score_min, score_max, zone, action, colour_hex) VALUES
    ( 1,  4, 'Low',      'Accept — monitor annually',               '92D050'),
    ( 5,  9, 'Medium',   'Monitor — review quarterly',              'FFC000'),
    (10, 19, 'High',     'Treat — implement controls immediately',  'FF6600'),
    (20, 25, 'Critical', 'Treat + Escalate — immediate escalation', 'FF0000')
ON CONFLICT DO NOTHING;


-- =============================================================================
-- PART 6: GRANT PERMISSIONS TO nrm_user
-- =============================================================================

GRANT USAGE ON SCHEMA public TO nrm_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES    IN SCHEMA public TO nrm_user;
GRANT USAGE, SELECT                  ON ALL SEQUENCES IN SCHEMA public TO nrm_user;

-- Ensure future tables created by postgres are also accessible
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES    TO nrm_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
    GRANT USAGE, SELECT                  ON SEQUENCES TO nrm_user;


-- =============================================================================
-- PART 7: VERIFICATION
-- =============================================================================

\echo ''
\echo '=== Tables created ==='
SELECT tablename AS table_name,
       pg_size_pretty(pg_total_relation_size(quote_ident(tablename))) AS size
FROM   pg_tables
WHERE  schemaname = 'public'
ORDER  BY tablename;

\echo ''
\echo '=== Reference data ==='
SELECT 'likelihood_scale'        AS table_name, COUNT(*) AS rows FROM likelihood_scale
UNION ALL
SELECT 'consequence_scale',                     COUNT(*) FROM consequence_scale
UNION ALL
SELECT 'risk_acceptance_criteria',              COUNT(*) FROM risk_acceptance_criteria;

\echo ''
\echo '✅  NRM schema ready.'
\echo '    Connection string: postgresql://nrm_user:nrm_pass@localhost:5432/nrm_db'
\echo ''